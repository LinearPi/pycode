# -*- coding: utf-8 -*-

"""
Created on Mon Oct  2 22:14:43 2017

@author: jinpeng.li
"""

class LayoutAnalysis(object):
    def __init__(self, ):
        pass

    def do(self, image):
        pass

class LayoutAnalysis1(object):
    def __init__(self, ):
        pass

    def do(self, image):
        pass

if __name__ == "__main__":
    import cv2
